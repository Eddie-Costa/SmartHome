from machine import Pin, ADC, I2C
from time import sleep
import dht
import network
import ssd1306
from umqtt.simple import MQTTClient
import json
import urequests
import ntptime
import time
import socket
import ssl
import binascii
import socket

ultimo_envio = 0

# LDR no GPIO 35
ldr = ADC(Pin(34))

# MQ2 no GPIO 34
mq2 = ADC(Pin(32))

# DHT no GPIO 15
DHT = dht.DHT22(Pin(25))

# Sensor PIR no GPIO 15
pir = Pin(23, Pin.IN)

# LED no GPIO 2
led = Pin(21, Pin.OUT)

# LED alerta
led2 = Pin(12, Pin.OUT)

# LED
led3 = Pin(17, Pin.OUT)

#Buzzer de alerta
buzzer = Pin(13, Pin.OUT)

#Painel OLED
i2c = I2C(0, scl=Pin(2), sda=Pin(15))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

btn_next = Pin(5, Pin.IN, Pin.PULL_UP)
btn_prev = Pin(18, Pin.IN, Pin.PULL_UP)

btn_next_pressionado = False
btn_prev_pressionado = False

def handler_next(pin):
    global btn_next_pressionado
    btn_next_pressionado = True

def handler_prev(pin):
    global btn_prev_pressionado
    btn_prev_pressionado = True

btn_next.irq(trigger=Pin.IRQ_FALLING, handler=handler_next)
btn_prev.irq(trigger=Pin.IRQ_FALLING, handler=handler_prev)


class sensores:
  def __init__(self):
    self.temperatura = 0
    self.umidade = 0
    self.gas = 0
    self.PorcentagemGas = 0
    self.Luminosidade = 0
    self.porcentagemLum = 0
    self.op = 0
    self.comodo_atual = 0
    self.nomes_comodos = ["Quarto", "Sala", "Cozinha", "Banheiro"]
    self.tela = 0
    self.total_telas = 4
    self.prev_next = 1
    self.prev_prev = 1
    self.alerta = 0
    self.oled = oled
    self.mensagem_alerta = ""
    self.email_enviado = False
    self.led1_manual = False
    self.led2_manual = False
    self.led3_manual = False

  #Inicia o servidor WEB
  def iniciar_servidor(self):
    self.servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    self.servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    self.servidor.bind(('', 80))
    self.servidor.listen(1)
    self.servidor.setblocking(False)
    print("Servidor web iniciado")  

  def verificar_servidor(self, client):
    try:
      conn, addr = self.servidor.accept()
      request = conn.recv(1024).decode()

      if "GET /led1/on" in request:
          self.led1_manual = True
          led.on()
          client.publish("SmartHome/Estado/LED1", "ON")
      elif "GET /led1/off" in request:
          self.led1_manual = False
          led.off()
          client.publish("SmartHome/Estado/LED1", "OFF")

      elif "GET /led2/on" in request:
          self.led2_manual = True
          led2.on()
          client.publish("SmartHome/Estado/LED2", "ON")
      elif "GET /led2/off" in request:
          self.led2_manual = False
          led2.off()
          client.publish("SmartHome/Estado/LED2", "OFF")

      elif "GET /led3/on" in request:
          self.led3_manual = True
          led3.on()
          client.publish("SmartHome/Estado/LED3", "ON")
      elif "GET /led3/off" in request:
          self.led3_manual = False
          led3.off()
          client.publish("SmartHome/Estado/LED3", "OFF")

      elif "GET /buzzer/on" in request:
          buzzer.on()
          client.publish("SmartHome/Estado/Buzzer", "ON")
      elif "GET /buzzer/off" in request:
          buzzer.off()
          client.publish("SmartHome/Estado/Buzzer", "OFF")  

      html = """<!DOCTYPE html>
<html>
<head>
    <title>SmartHome</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {{ font-family: Arial; text-align: center; background: #1a1a2e; color: white; }}
        h1 {{ color: #e94560; }}
        h2 {{ color: #0f3460; background: #16213e; padding: 10px; border-radius: 8px; }}
        .btn-on {{ background: #4CAF50; color: white; padding: 12px 24px; border: none; border-radius: 8px; margin: 5px; font-size: 16px; cursor: pointer; }}
        .btn-off {{ background: #e94560; color: white; padding: 12px 24px; border: none; border-radius: 8px; margin: 5px; font-size: 16px; cursor: pointer; }}
        .card {{ background: #16213e; border-radius: 12px; padding: 15px; margin: 10px auto; width: 80%; }}
        .sensor {{ font-size: 18px; margin: 5px; }}
    </style>
</head>
<body>
    <h1>SmartHome ESP32</h1>
    <div class="card">
        <h2>Sensores - {comodo}</h2>
        <p class="sensor">🌡️ Temperatura: {temp:.1f} C</p>
        <p class="sensor">💧 Umidade: {umid:.1f} %</p>
        <p class="sensor">💡 Luminosidade: {luz:.1f} %</p>
        <p class="sensor">💨 Gas: {gas:.1f} %</p>
    </div>
    <div class="card">
        <h2>Controle de Atuadores</h2>
        <p>LED Presença</p>
        <a href="/led1/on"><button class="btn-on">Ligar</button></a>
        <a href="/led1/off"><button class="btn-off">Desligar</button></a>
        <p>LED Alerta</p>
        <a href="/led2/on"><button class="btn-on">Ligar</button></a>
        <a href="/led2/off"><button class="btn-off">Desligar</button></a>
        <p>LED Ambiente</p>
        <a href="/led3/on"><button class="btn-on">Ligar</button></a>
        <a href="/led3/off"><button class="btn-off">Desligar</button></a>
        <p>Buzzer</p>
        <a href="/buzzer/on"><button class="btn-on">Ligar</button></a>
        <a href="/buzzer/off"><button class="btn-off">Desligar</button></a>
    </div>
</body>
</html>""".format(
            comodo=self.nomes_comodos[self.comodo_atual],
            temp=self.temperatura,
            umid=self.umidade,
            luz=self.porcentagemLum,
            gas=self.PorcentagemGas
        )

      conn.send("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n")
      conn.send(html)
      conn.close()

    except:
        pass    

  #Utiliza o sensor DHT para medir umidade e temperatura
  def LerDHT(self):
    DHT.measure()

    self.temperatura = DHT.temperature()
    self.umidade = DHT.humidity()

    print("Temperatura:", self.temperatura, "°C")
    print("Umidade:", self.umidade, "%")

  #Utiliza o sensor PIR para detectar presença no comodo
  def SensorMovimento(self):
    if self.led1_manual:  # <- não mexe se está em modo manual
      return
    movimento = pir.value()
    if movimento == 1:
      print("Movimento detectado!")
      led.on()
    else:
      print("Sem movimento")
      led.off()
  
  #Utiliza o sensor MQ2 para medir a presença de gas no comodo
  def LerMQ2(self):
    mq2.atten(ADC.ATTN_11DB)
    self.gas = mq2.read()
    print("Gas:", self.gas)

  #Utiliza o sensor LDR para medir a luminosidade do ambiente
  def LerLDR(self):
    ldr.atten(ADC.ATTN_11DB)
    self.Luminosidade = ldr.read()
    print("Luminosidade:", self.Luminosidade)
  
  #Envia os dados ao endpoint mqtt correpondente
  def enviar_dados(self, client):
    
    self.porcentagemLum = self.Luminosidade/100
    self.PorcentagemGas = self.gas/100

    payload = {
    "temperatura": self.temperatura,
    "umidade": self.umidade,
    "luz": self.porcentagemLum,
    "gas": self.PorcentagemGas
    }

    msg = json.dumps(payload)

    if obj.comodo_atual == 0:
      client.publish("SmartHome/Quarto", msg)  
    elif obj.comodo_atual == 1:
      client.publish("SmartHome/Sala", msg)  
    elif obj.comodo_atual == 2:
      client.publish("SmartHome/Cozinha", msg)  
    elif obj.comodo_atual == 3:
      client.publish("SmartHome/Banheiro", msg)  

  #Envia os dados ao google sheets
  def enviar_google_sheets(self):
        
    url = "https://script.google.com/macros/s/AKfycbwnli9d_6ib3clky7nCSmQxtqVbEPiEBSsPVadlUF79QqFs3YhYO1ivwZpL24_Cj-YW/exec"

    payload = {
        "comodo": self.nomes_comodos[self.comodo_atual],
        "datahora": self.obter_datahora(),
        "temperatura": self.temperatura,
        "umidade": self.umidade,
        "luz": self.porcentagemLum,
        "gas": self.PorcentagemGas
    }

    headers = {
        "Content-Type": "application/json"
    }

    resposta = urequests.post(
        url,
        data=json.dumps(payload),
        headers=headers
    )

    print(resposta.text)
    resposta.close()

  #Obtem a data e hora atual  
  def obter_datahora(self):
    try:
        utc_offset = -3 * 3600

        agora = time.localtime(time.time() + utc_offset)

        datahora = "{:02d}/{:02d}/{} {:02d}:{:02d}:{:02d}".format(
            agora[2],
            agora[1],
            agora[0],
            agora[3],
            agora[4],
            agora[5]
        )

        return datahora
    except:
        return "Sem horario"

  def RegraNegocio(self):
    self.alerta = 0
    alerta_anterior = self.email_enviado

    if self.temperatura > 22:
        self.alerta = 1
        self.mensagem_alerta = "Temp alta: {:.1f}C".format(self.temperatura)
    elif self.temperatura < 18:
        self.alerta = 1
        self.mensagem_alerta = "Temp baixa: {:.1f}C".format(self.temperatura)

    if self.umidade < 50:
        self.alerta = 1
        self.mensagem_alerta = "Umid baixa: {:.1f}%".format(self.umidade)
    elif self.umidade > 60:
        self.alerta = 1
        self.mensagem_alerta = "Umid alta: {:.1f}%".format(self.umidade)

    if self.PorcentagemGas > 80:
        self.alerta = 1
        self.mensagem_alerta = "Gas alto: {}%".format(self.PorcentagemGas)
        if not self.led2_manual:
            led2.on()
        self.BuzzerOscilation()
        self.BuzzerOscilation()
        self.BuzzerOscilation()
        self.BuzzerOscilation()
    else:
        if not self.led2_manual:
            led2.off()
        buzzer.off()

    if self.porcentagemLum < 20:
        self.alerta = 1
        self.mensagem_alerta = "Luz baixa: {}%".format(self.porcentagemLum)
        if not self.led3_manual:
            led3.on()
    else:
        if not self.led3_manual:
            led3.off()

    if self.alerta == 1 and not self.email_enviado:
        self.email_enviado = True
        self.enviar_email()

    if self.alerta == 0:
        self.email_enviado = False

  #Conectar Wi-fi    
  def conectar_wifi(self, ssid, senha):
    wifi = network.WLAN(network.STA_IF)
    wifi.active(True)

    if not wifi.isconnected():
      print("Conectando ao WiFi...")
      wifi.connect(ssid, senha)

      while not wifi.isconnected():
        pass

    ntptime.settime()
    wifi = network.WLAN(network.STA_IF)
    print("IP:", wifi.ifconfig()[0])  

  #Conectar com mqtt
  def conectar_mqtt(self):
    client = MQTTClient(
        client_id="esp32",
        server="broker.hivemq.com",
        port=1883
    )

    client.set_callback(self.receber_comando)
    client.connect()
    client.subscribe("SmartHome/Controle/LED1")
    client.subscribe("SmartHome/Controle/LED2")
    client.subscribe("SmartHome/Controle/LED3")
    return client
  
  def receber_comando(self, topic, msg):
    topic = topic.decode()
    msg = msg.decode().strip()

    if topic == "SmartHome/Controle/LED1":
      if msg == "ON":
          self.led1_manual = True
          led.on()
      elif msg == "OFF":
          self.led1_manual = False
          led.off()

    elif topic == "SmartHome/Controle/LED2":
      if msg == "ON":
          self.led2_manual = True
          led2.on()
      elif msg == "OFF":
          self.led2_manual = False
          led2.off()

    elif topic == "SmartHome/Controle/LED3":
      if msg == "ON":
          self.led3_manual = True
          led3.on()
      elif msg == "OFF":
          self.led3_manual = False
          led3.off()

  def comodos(self):
    print("Qual cômodo você quer medir?")
    print("1- Quarto")
    print("2- Sala")
    print("3- Cozinha")
    print("4- Banheiro")

  #Faz o Buzzer apitar rapidamente para imitar um alarme
  def BuzzerOscilation(self):
    buzzer.on()
    buzzer.off()

  #Exibe o conteudo no display
  def exibirDisplay(self):
    global btn_next_pressionado, btn_prev_pressionado

    if btn_next_pressionado:
        btn_next_pressionado = False
        self.tela += 1
        if self.tela >= self.total_telas:
            self.tela = 0
            obj.comodo_atual = (obj.comodo_atual + 1) % 4

    if btn_prev_pressionado:
        btn_prev_pressionado = False
        self.tela -= 1
        if self.tela < 0:
            self.tela = self.total_telas - 1
            obj.comodo_atual = (obj.comodo_atual - 1) % 4

    self.oled.fill(0)

    if self.alerta == 1:
        self.oled.text("!! ALERTA !!", 0, 0)
        self.oled.text(self.mensagem_alerta, 0, 20)
        self.oled.text("Comodo:", 0, 40)
        self.oled.text(self.nomes_comodos[obj.comodo_atual], 0, 50)

    elif self.tela == 0:
        self.oled.text("Comodo:", 0, 0)
        self.oled.text(self.nomes_comodos[obj.comodo_atual], 0, 10)
        self.oled.text("TEMPERATURA", 0, 25)
        self.oled.text("Temp: {:.1f}C".format(self.temperatura), 0, 40)

    elif self.tela == 1:
        self.oled.text("Comodo:", 0, 0)
        self.oled.text(self.nomes_comodos[obj.comodo_atual], 0, 10)
        self.oled.text("UMIDADE", 0, 25)
        self.oled.text("Umid: {:.1f}%".format(self.umidade), 0, 40)

    elif self.tela == 2:
        self.oled.text("Comodo:", 0, 0)
        self.oled.text(self.nomes_comodos[obj.comodo_atual], 0, 10)
        self.oled.text("LUMINOSIDADE", 0, 25)
        self.oled.text("Luz: {}%".format(self.porcentagemLum), 0, 40)

    elif self.tela == 3:
        self.oled.text("Comodo:", 0, 0)
        self.oled.text(self.nomes_comodos[obj.comodo_atual], 0, 10)
        self.oled.text("QUALIDADE AR", 0, 25)
        self.oled.text("Gas: {}%".format(self.PorcentagemGas), 0, 40)

    self.oled.show()

  def ler_resposta(self, smtp):
    resposta = b""
    while True:
        chunk = smtp.read(1)
        if not chunk:
            break
        resposta += chunk
        if resposta.endswith(b"\n"):
            break
    print("SMTP:", resposta.decode())
    return resposta

  def enviar_email(self):
    remetente = "estacaometeorologicaeddie@gmail.com"
    senha = "gykmrqobsutkjssl"
    destinatario = "eddiealencarcosta@gmail.com"
    assunto = "Alerta SmartHome"

    mensagem = """\
Comodo: {}
Data: {}

Temperatura: {:.1f} C
Umidade: {:.1f} %
Luminosidade: {:.1f} %
Gas: {:.1f} %

Alerta: {}
""".format(
        self.nomes_comodos[self.comodo_atual],
        self.obter_datahora(),
        self.temperatura,
        self.umidade,
        self.porcentagemLum,
        self.PorcentagemGas,
        self.mensagem_alerta
    )

    email = """\
From: {}
To: {}
Subject: {}

{}
""".format(remetente, destinatario, assunto, mensagem)

    try:
        print("Conectando SMTP...")
        addr = socket.getaddrinfo("smtp.gmail.com", 465)[0][-1]
        sock = socket.socket()
        sock.connect(addr)
        smtp = ssl.wrap_socket(sock, server_hostname="smtp.gmail.com")

        self.ler_resposta(smtp)
        smtp.write(b"EHLO esp32\r\n")
        self.ler_resposta(smtp)
        smtp.write(b"AUTH LOGIN\r\n")
        self.ler_resposta(smtp)
        smtp.write(binascii.b2a_base64(remetente.encode()).strip() + b"\r\n")
        self.ler_resposta(smtp)
        smtp.write(binascii.b2a_base64(senha.encode()).strip() + b"\r\n")
        self.ler_resposta(smtp)
        smtp.write(b"MAIL FROM:<%s>\r\n" % remetente.encode())
        self.ler_resposta(smtp)
        smtp.write(b"RCPT TO:<%s>\r\n" % destinatario.encode())
        self.ler_resposta(smtp)
        smtp.write(b"DATA\r\n")
        self.ler_resposta(smtp)
        smtp.write(email.encode())
        smtp.write(b"\r\n.\r\n")
        self.ler_resposta(smtp)
        smtp.write(b"QUIT\r\n")
        self.ler_resposta(smtp)
        smtp.close()
        print("Email enviado com sucesso!")

    except Exception as e:
        print("Erro ao enviar email:", e)

#definição de objetos
obj = sensores()
obj.conectar_wifi("Wokwi-GUEST", "")
cliente = obj.conectar_mqtt()
obj.iniciar_servidor() 
obj.comodo_atual = 0
estado_anterior = 1


print("Cômodo atual:", obj.nomes_comodos[obj.comodo_atual])


while True:
  cliente.check_msg()
  obj.verificar_servidor(cliente)

  print("""                                                                        
                          
                          
                          
                          
                          
                          """)

  print(" ")

  obj.LerDHT()
  obj.SensorMovimento()
  obj.LerMQ2()
  obj.LerLDR()
  obj.RegraNegocio()
  obj.enviar_dados(cliente)
  obj.exibirDisplay()

  agora = time.time()
  if agora - ultimo_envio >= 7200:
    obj.enviar_google_sheets()
    ultimo_envio = agora

  sleep(1)  
  print(" ")